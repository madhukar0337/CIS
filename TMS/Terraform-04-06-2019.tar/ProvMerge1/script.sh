#!/bin/bash
sudo yum update -y
sudo yum install tomcat8 -y
sudo service tomcat8 start
