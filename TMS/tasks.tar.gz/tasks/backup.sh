#!/bin/bash
  tar -cvf /home/siva/jenkins1.tar /home/siva/.jenkins
  gzip /home/siva/jenkins1.tar
  scp /home/siva/jenkins1.tar.gz bharath@192.168.5.47:/home/bharath
